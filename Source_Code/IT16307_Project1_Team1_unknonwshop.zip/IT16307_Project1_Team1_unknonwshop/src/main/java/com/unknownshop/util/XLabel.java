/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.unknownshop.util;

import javax.swing.JLabel;

/**
 *
 * @author Dell
 */
public class XLabel {
    public static JLabel lblHomeTotalQuantity;
    public static JLabel lblHomeTotalPrice;
    public static JLabel lblCartTotalQuantity;
    public static JLabel lblCartTotalPrice;
}
