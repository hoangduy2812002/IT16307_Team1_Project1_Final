/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.unknownshop.util;

import com.unknownshop.entity.Products;
import com.unknownshop.entity.Users;
import java.util.List;

/**
 *
 * @author Dell
 */
public class XList {

    public static List<Products> listAo;
    public static List<Products> listQuan;
    public static List<Products> listPhuKien;
    public static List<Products> listGiay;
    public static List<Users> listUser;
    public static List<String> listName;

}
